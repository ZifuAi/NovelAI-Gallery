'use strict';

const THEMES = {
  dark: [
    ['midnight', 'Midnight'], ['graphite', 'Graphite'], ['nocturne', 'Nocturne'],
    ['forest', 'Forest'], ['ember', 'Ember'], ['orchid', 'Orchid'],
    ['ocean', 'Ocean'], ['rose', 'Rose'], ['sand', 'Sand'], ['void', 'Void'],
  ],
  light: [
    ['daylight', 'Daylight'], ['paper', 'Paper'], ['mist', 'Mist'],
    ['linen', 'Linen'], ['meadow', 'Meadow'], ['blossom', 'Blossom'],
    ['porcelain', 'Porcelain'], ['sky', 'Sky'], ['honey', 'Honey'], ['lavender', 'Lavender'],
  ],
};

const CAPTURE_MODES = [
  {
    id: 'generated',
    title: 'Only save images as I generate them',
    desc: 'New generations land here automatically. Your existing NovelAI history is left alone — use “Import NovelAI history now” in the extension popup if you ever want to pull the backlog in.',
  },
  {
    id: 'all',
    title: 'Save everything, including my existing history',
    desc: 'As above, but also imports whatever NovelAI already has stored the first time it runs. Best if you want a complete archive.',
  },
  {
    id: 'download',
    title: 'Only save images I save or download',
    desc: 'Nothing is saved automatically. A copy lands here whenever you save an image on NovelAI — its own save button, or right-click → Save image as. Your download still goes to your Downloads folder as normal.',
  },
];

const LAYOUTS = ['grid', 'justified', 'waterfall', 'list'];

const META_VIEWS = [
  {
    id: 'tags',
    title: 'As tags',
    desc: 'Each comma-separated part becomes its own chip, grouped into collapsible sections. Clicking a tag searches for it.',
  },
  {
    id: 'raw',
    title: 'As raw text',
    desc: 'The prompt exactly as it was written, in a text box you can select and copy from in one go.',
  },
];

const state = {
  query: '',
  view: 'all',
  folderId: null,
  offset: 0,
  limit: 60,
  total: 0,
  items: [],
  current: null,     // shown in the lightbox
  selected: null,    // shown in the inspector panel
  loading: false,
  settings: {
    theme: 'midnight', cardSize: 190, inspectorOpen: true,
    captureMode: 'generated', layout: 'grid', sort: 'newest',
    metaView: 'tags', interceptDownloads: false,
  },
  collapsed: {},     // section id -> true when collapsed
  selection: new Set(),  // ids ticked in multi-select mode
  selectMode: false,
  anchorId: null,    // for shift-click ranges
  folders: [],
};

const $ = (id) => document.getElementById(id);
const el = {};
[
  'app', 'content', 'search', 'searchClear', 'countPill', 'countAll', 'countFav', 'countPin',
  'refreshBtn', 'folderList', 'addFolderBtn', 'lightbox', 'viewerImg', 'detailsBody',
  'favBtn', 'pinBtn', 'closeBtn', 'toast', 'zoom', 'inspector', 'inspectorBody',
  'inspectorToggle', 'inspectorClose', 'settingsBtn', 'settingsModal', 'settingsClose',
  'darkThemes', 'lightThemes', 'captureModes', 'metaViews', 'interceptSwitch',
  'onboardModal', 'onboardBody', 'onboardDots', 'onboardBack', 'onboardNext',
  'onboardSkip', 'onboardStepLabel', 'ctxMenu',
  'importBtn', 'importInput', 'dropzone',
  'extModal', 'extBody', 'extClose', 'setupExtBtn', 'extStatus', 'extDot', 'extStatusText',
  'sortSelect', 'layoutSwitch', 'selectBtn', 'deleteBtn', 'expandBtn',
  'zoomView', 'zoomCanvas', 'zoomImg', 'zoomBack', 'zoomIn', 'zoomOut',
  'zoomLevel', 'zoomName', 'zoomHint',
  'bulkbar', 'bulkCount', 'bulkSelectAll', 'bulkPin', 'bulkFav',
  'bulkFolderBtn', 'bulkFolderMenu', 'bulkDelete', 'bulkClose',
  'clearGalleryBtn', 'clearCount',
  'confirmModal', 'confirmTitle', 'confirmBody', 'confirmOk', 'confirmCancel',
].forEach((id) => { el[id] = $(id); });
el.app = document.getElementById('app');

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[c]));

let toastTimer;
function toast(msg) {
  el.toast.textContent = msg;
  el.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.toast.classList.remove('show'), 1900);
}

// ---------------------------------------------------------------- settings

async function loadSettings() {
  try {
    const s = await fetch('/api/settings').then((r) => r.json());
    state.settings = { ...state.settings, ...s };
  } catch (e) {
    /* fall back to defaults */
  }
  applySettings();
}

function applySettings() {
  document.documentElement.setAttribute('data-theme', state.settings.theme);
  document.documentElement.style.setProperty('--card-size', `${state.settings.cardSize}px`);
  el.zoom.value = state.settings.cardSize;
  el.app.classList.toggle('inspector-open', !!state.settings.inspectorOpen);
  el.inspectorToggle.classList.toggle('active', !!state.settings.inspectorOpen);

  if (!LAYOUTS.includes(state.settings.layout)) state.settings.layout = 'grid';
  el.layoutSwitch.querySelectorAll('.layout-btn').forEach((b) => {
    b.classList.toggle('active', b.dataset.layout === state.settings.layout);
  });
  el.app.dataset.layout = state.settings.layout;
  el.sortSelect.value = state.settings.sort || 'newest';
  // The zoom slider means "row height" or "column width" depending on the
  // layout, and nothing at all in list view.
  el.zoom.parentElement.classList.toggle('disabled', state.settings.layout === 'list');

  syncWindowChrome();
}

/**
 * Hand the window's title bar the theme's colors.
 *
 * The caption is painted by Windows, not by this page, so a themed app
 * with a stock title bar looks half-finished. The app passes these on to
 * the desktop window manager; Windows 10 can't colour a caption, so there
 * only the light/dark part applies. Everywhere else it's a no-op.
 */
let lastChrome = '';
function syncWindowChrome() {
  const css = getComputedStyle(document.documentElement);
  const chrome = {
    caption: css.getPropertyValue('--surface-1').trim(),
    text: css.getPropertyValue('--text').trim(),
    border: css.getPropertyValue('--border').trim(),
    dark: THEMES.dark.some(([id]) => id === state.settings.theme),
  };
  const key = JSON.stringify(chrome);
  if (!chrome.caption || key === lastChrome) return;
  lastChrome = key;
  fetch('/api/window/chrome', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(chrome),
  }).catch(() => { /* not running inside the desktop window */ });
}

/**
 * A styled yes/no for destructive actions. Deliberately not window.confirm:
 * deleting a library needs to state exactly what is about to go, and the
 * native dialog can't.
 */
function confirmDialog({ title, body, confirmLabel = 'Delete' }) {
  return new Promise((resolve) => {
    el.confirmTitle.textContent = title;
    el.confirmBody.innerHTML = body;
    el.confirmOk.textContent = confirmLabel;
    el.confirmModal.hidden = false;
    el.confirmOk.focus();

    const done = (answer) => {
      el.confirmModal.hidden = true;
      el.confirmOk.removeEventListener('click', ok);
      el.confirmCancel.removeEventListener('click', cancel);
      el.confirmModal.removeEventListener('click', backdrop);
      document.removeEventListener('keydown', key, true);
      resolve(answer);
    };
    const ok = () => done(true);
    const cancel = () => done(false);
    const backdrop = (e) => { if (e.target === el.confirmModal) done(false); };
    const key = (e) => {
      if (e.key === 'Escape') { e.stopPropagation(); done(false); }
      if (e.key === 'Enter') { e.stopPropagation(); done(true); }
    };

    el.confirmOk.addEventListener('click', ok);
    el.confirmCancel.addEventListener('click', cancel);
    el.confirmModal.addEventListener('click', backdrop);
    document.addEventListener('keydown', key, true);
  });
}

let saveTimer;
function saveSettings(patch) {
  state.settings = { ...state.settings, ...patch };
  applySettings();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state.settings),
    }).catch(() => {});
  }, 180);
}

/* The theme grid, the prompt-display choice, the capture modes and the
   save switch all appear in two places now - Settings and the first-run
   setup - so each one is a renderer that takes a container rather than
   markup written twice. */

function themeSwatchHtml(id, name) {
  return `
    <button class="theme-swatch${state.settings.theme === id ? ' active' : ''}" data-theme-id="${id}">
      <div class="swatch-preview" data-theme="${id}" style="background:var(--bg)">
        <div class="swatch-chip" style="background:var(--accent)"></div>
        <div class="swatch-bar" style="background:var(--surface-3)"></div>
      </div>
      <span class="swatch-name">${esc(name)}</span>
    </button>`;
}

function renderThemePicker(darkEl, lightEl, onPick) {
  if (darkEl) darkEl.innerHTML = THEMES.dark.map(([id, n]) => themeSwatchHtml(id, n)).join('');
  if (lightEl) lightEl.innerHTML = THEMES.light.map(([id, n]) => themeSwatchHtml(id, n)).join('');
  [darkEl, lightEl].forEach((root) => {
    if (!root) return;
    root.querySelectorAll('.theme-swatch').forEach((b) => {
      b.addEventListener('click', () => {
        saveSettings({ theme: b.dataset.themeId });
        if (onPick) onPick(b);
      });
    });
  });
}

function optionListHtml(options, selectedId) {
  return options.map((m) => `
    <div class="option${selectedId === m.id ? ' selected' : ''}" data-option="${m.id}">
      <div class="option-radio"></div>
      <div class="option-text">
        <div class="option-title">${esc(m.title)}</div>
        <div class="option-desc">${esc(m.desc)}</div>
      </div>
    </div>`).join('');
}

function renderMetaViews(container, onPick) {
  if (!container) return;
  container.innerHTML = optionListHtml(META_VIEWS, state.settings.metaView || 'tags');
  container.querySelectorAll('.option').forEach((o) => {
    o.addEventListener('click', () => {
      saveSettings({ metaView: o.dataset.option });
      renderMetaViews(container, onPick);
      renderInspector();
      if (state.current) renderDetails();
      if (onPick) onPick(o.dataset.option);
    });
  });
}

function renderCaptureModes(container, onPick) {
  if (!container) return;
  container.innerHTML = optionListHtml(CAPTURE_MODES, state.settings.captureMode);
  container.querySelectorAll('.option').forEach((o) => {
    o.addEventListener('click', () => {
      saveSettings({ captureMode: o.dataset.option });
      renderCaptureModes(container, onPick);
      if (onPick) onPick(o.dataset.option);
    });
  });
}

function renderInterceptSwitch(container) {
  if (!container) return;
  container.innerHTML = `
    <label class="switch-row">
      <input type="checkbox" class="switch-input"${state.settings.interceptDownloads ? ' checked' : ''} />
      <span class="switch-track"><span class="switch-knob"></span></span>
      <span class="switch-text">
        <span class="switch-title">Keep saved images here instead of downloading them</span>
        <span class="switch-desc">
          When you save an image on NovelAI, it goes straight into this gallery
          and no file is written to your Downloads folder. Only applies to
          NovelAI — nothing else you download is touched.
        </span>
      </span>
    </label>`;
  const input = container.querySelector('.switch-input');
  input.addEventListener('change', () => {
    saveSettings({ interceptDownloads: input.checked });
    toast(input.checked
      ? 'Saved images will be kept here instead of downloaded.'
      : 'Saved images will download normally again.');
  });
}

function renderSettings() {
  renderThemePicker(el.darkThemes, el.lightThemes, (b) => {
    renderSettings();
    toast(`Theme: ${b.querySelector('.swatch-name').textContent}`);
  });
  renderMetaViews(el.metaViews);
  renderCaptureModes(el.captureModes, () =>
    toast('Capture mode updated — the extension picks this up within a minute.'));
  renderInterceptSwitch(el.interceptSwitch);
}

// ---------------------------------------------------------------- storage

// Where the library lives on disk. Every captured image - including one
// saved with "keep saved images here" - is an ordinary .png in this
// folder, and the details panel says so.
let storageInfo = null;
async function loadStorageInfo() {
  try {
    storageInfo = await fetch('/api/storage').then((r) => r.json());
  } catch (e) { /* the path line is simply omitted */ }
}

function imagePathOf(record) {
  if (!storageInfo?.imagesDir || !record?.filename) return '';
  const sep = storageInfo.imagesDir.includes('\\') ? '\\' : '/';
  return `${storageInfo.imagesDir}${sep}${record.filename}`;
}

async function revealImage(record, btn) {
  const original = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  try {
    const res = await fetch(`/api/images/${record.id}/reveal`, { method: 'POST' });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`);
    toast('Opened in File Explorer');
  } catch (e) {
    toast(e.message || 'Could not open the folder');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = original; }
  }
}

// ---------------------------------------------------------------- extension setup

/**
 * Whether the extension is actually installed and talking to us. There's
 * no way to query the browser directly, so this infers it: if anything in
 * the library arrived via the extension, it's working. Before the first
 * capture we can only say "not detected yet", and say so honestly rather
 * than claiming it's missing.
 */
async function extensionStatus() {
  try {
    const data = await fetch('/api/images?limit=1').then((r) => r.json());
    const seen = data.total > 0;
    return seen ? 'working' : 'unknown';
  } catch (e) {
    return 'unknown';
  }
}

async function refreshExtStatus() {
  const status = await extensionStatus();
  if (status === 'working') {
    el.extDot.className = 'dot ok';
    el.extStatusText.textContent = 'Installed and saving images';
  } else {
    el.extDot.className = 'dot';
    el.extStatusText.textContent = 'No images captured yet';
  }
}

async function openExtensionSetup() {
  el.onboardModal.hidden = true;
  el.extModal.hidden = false;
  renderExtensionSteps(el.extBody);
}

/** The install-the-extension walkthrough, used by the modal and by setup. */
async function renderExtensionSteps(container) {
  container.innerHTML = '<div class="empty-note">Loading…</div>';

  let info = { path: '', browsers: [] };
  try {
    info = await fetch('/api/extension/info').then((r) => r.json());
  } catch (e) { /* fall through with empty info */ }

  const browsers = info.browsers || [];
  const browserBtns = browsers.length
    ? browsers.map((b) => `<button class="btn primary" data-browser="${esc(b.id)}">Open ${esc(b.name)}</button>`).join('')
    : `<div class="sub">No Brave/Chrome/Edge install found automatically — open your browser yourself and go to its Extensions page.</div>`;

  container.innerHTML = `
    <div class="steps">
      <div class="step">
        <div class="step-num"></div>
        <div class="step-text">
          Open your browser's Extensions page.
          <div class="sub">This button opens it for you.</div>
          <div class="browser-row">${browserBtns}</div>
        </div>
      </div>

      <div class="step">
        <div class="step-num"></div>
        <div class="step-text">
          Turn on <strong>Developer mode</strong> — the switch in the top-right of that page.
        </div>
      </div>

      <div class="step">
        <div class="step-num"></div>
        <div class="step-text">
          Click <strong>Load unpacked</strong>, then pick this folder:
          <div class="path-box">
            <code>${esc(info.path || 'unavailable')}</code>
            <button class="btn" data-copy-path>Copy</button>
            <button class="btn" data-open-folder>Open</button>
          </div>
        </div>
      </div>

      <div class="step">
        <div class="step-num"></div>
        <div class="step-text">
          Reload your NovelAI tab once, then generate an image — it should
          appear here on its own.
          <div class="sub">Extensions only attach to pages that load after they're installed.</div>
        </div>
      </div>
    </div>

    <div class="callout">
      Browsers only allow one-click installs for extensions published to their
      web store, and this one isn't. That's why the folder step above is manual —
      it's the same thing every unpublished extension needs, and it's a one-time setup.
    </div>`;

  container.querySelectorAll('[data-browser]').forEach((b) => {
    const label = b.textContent;
    b.addEventListener('click', async () => {
      b.disabled = true;
      b.textContent = 'Opening…';
      try {
        await fetch('/api/extension/launch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ browser: b.dataset.browser }),
        });
        toast('Browser opened — continue with step 2');
      } catch (e) {
        toast('Could not open the browser automatically');
      }
      b.disabled = false;
      b.textContent = label;
    });
  });

  const copyBtn = container.querySelector('[data-copy-path]');
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(info.path || '').then(() => {
        copyBtn.textContent = 'Copied';
        setTimeout(() => (copyBtn.textContent = 'Copy'), 1400);
      }).catch(() => toast('Could not copy — select the path manually'));
    });
  }

  const openBtn = container.querySelector('[data-open-folder]');
  if (openBtn) {
    openBtn.addEventListener('click', async () => {
      try {
        await fetch('/api/extension/reveal', { method: 'POST' });
      } catch (e) {
        toast('Could not open the folder');
      }
    });
  }
}

/* ---------------------------------------------------------------- setup

   First run walks through the things worth deciding once - how it looks,
   how prompts read, what gets saved - and finishes on the one step that
   actually matters, installing the extension. Every choice is a live
   setting, so the app is already configured by the time it's dismissed;
   nothing here is a questionnaire whose answers get applied later.
*/

const ONBOARD_STEPS = [
  {
    id: 'welcome',
    render(c) {
      c.innerHTML = `
        <div class="onboard-hero">
          <img class="onboard-mark" src="appicon.png" alt="" />
          <h1 class="onboard-title">Welcome to NovelAI Gallery</h1>
          <p class="onboard-lead">
            This app keeps every image you generate on NovelAI, together with its
            prompt and settings, so you can search and reuse them later.
            Everything stays on this PC.
          </p>
          <div class="onboard-note">
            Four quick questions, then one real step: installing the browser
            extension. Without it, nothing arrives here.
          </div>
        </div>`;
    },
  },
  {
    id: 'theme',
    title: 'Pick a look',
    lead: 'All 20 themes are here in Settings whenever you want to change it.',
    render(c) {
      c.innerHTML = `
        <div class="theme-heading">Dark</div>
        <div class="theme-grid" data-dark></div>
        <div class="theme-heading">Light</div>
        <div class="theme-grid" data-light></div>`;
      const rerender = () => ONBOARD_STEPS[1].render(c);
      renderThemePicker(c.querySelector('[data-dark]'), c.querySelector('[data-light]'), rerender);
    },
  },
  {
    id: 'prompts',
    title: 'How should prompts read?',
    lead: 'This is what you see when you open one of your images.',
    render(c) { renderMetaViews(c); },
  },
  {
    id: 'saving',
    title: 'What should be saved?',
    lead: 'The browser extension does the saving; this is what you want it to catch.',
    render(c) {
      c.innerHTML = `<div data-modes></div><div data-switch></div>`;
      renderCaptureModes(c.querySelector('[data-modes]'));
      renderInterceptSwitch(c.querySelector('[data-switch]'));
    },
  },
  {
    id: 'extension',
    title: 'Install the browser extension',
    lead: 'This is the part that actually fills the gallery.',
    render(c) { renderExtensionSteps(c); },
  },
  {
    id: 'done',
    render(c) {
      c.innerHTML = `
        <div class="onboard-hero">
          <div class="onboard-tick">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 12.5l5 5L20 6.5"></path>
            </svg>
          </div>
          <h1 class="onboard-title">That's everything</h1>
          <p class="onboard-lead">
            Generate something on NovelAI and it should land here within a few
            seconds. If it doesn't, click the extension's toolbar icon — it
            tells you whether it can see the app and your NovelAI tab.
          </p>
          <div class="onboard-note">
            Anything you picked here lives in <strong>Settings</strong>, and
            nothing is final.
          </div>
        </div>`;
    },
  },
];

function maybeStartOnboarding() {
  if (state.settings.onboarded) return;
  state.onboardStep = 0;
  el.onboardModal.hidden = false;
  renderOnboardStep();
}

function renderOnboardStep() {
  const i = state.onboardStep;
  const step = ONBOARD_STEPS[i];

  el.onboardBody.innerHTML = '';
  if (step.title) {
    const head = document.createElement('div');
    head.className = 'onboard-step-head';
    head.innerHTML = `<h2 class="onboard-step-title">${esc(step.title)}</h2>
      ${step.lead ? `<p class="onboard-step-lead">${esc(step.lead)}</p>` : ''}`;
    el.onboardBody.appendChild(head);
  }
  const body = document.createElement('div');
  body.className = 'onboard-step-body';
  el.onboardBody.appendChild(body);
  step.render(body);
  el.onboardBody.scrollTop = 0;

  el.onboardDots.innerHTML = ONBOARD_STEPS
    .map((s2, n) => `<span class="onboard-dot${n === i ? ' active' : ''}${n < i ? ' done' : ''}"></span>`)
    .join('');
  el.onboardBack.style.visibility = i === 0 ? 'hidden' : 'visible';
  el.onboardNext.textContent = i === ONBOARD_STEPS.length - 1 ? 'Start using it' : 'Continue';
  el.onboardStepLabel.textContent = `${i + 1} of ${ONBOARD_STEPS.length}`;
}

function finishOnboarding() {
  el.onboardModal.hidden = true;
  saveSettings({ onboarded: true });
  load({ reset: true });
}

function onboardNext() {
  if (state.onboardStep >= ONBOARD_STEPS.length - 1) return finishOnboarding();
  state.onboardStep++;
  renderOnboardStep();
}

function onboardBack() {
  if (state.onboardStep === 0) return;
  state.onboardStep--;
  renderOnboardStep();
}

// ---------------------------------------------------------------- data

function buildParams() {
  const p = new URLSearchParams({ limit: String(state.limit), offset: String(state.offset) });
  if (state.query) p.set('q', state.query);
  if (state.view === 'favorites') p.set('favorite', 'true');
  if (state.view === 'pinned') p.set('pinned', 'true');
  if (state.folderId) p.set('folder', state.folderId);
  if (state.settings.sort) p.set('sort', state.settings.sort);
  return p;
}

async function load({ reset, silent } = {}) {
  if (state.loading) return;
  state.loading = true;
  if (reset) {
    state.offset = 0;
    state.items = [];
    // The skeleton is a first-load affordance only. It used to appear
    // whenever there was no .grid on screen, which meant an empty library
    // flashed a grid of placeholder tiles on every background refresh -
    // the gallery looked like it was loading images that don't exist.
    // Anything already on screen, grid or empty state, now simply stays
    // until the new data replaces it.
    if (!silent && !el.content.querySelector('.grid, .state')) renderSkeleton();
  }
  try {
    const res = await fetch(`/api/images?${buildParams()}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state.total = data.total;
    state.items = state.items.concat(data.items);
    state.offset += data.items.length;
    render();
    refreshCounts();
  } catch (err) {
    renderError(err.message);
  } finally {
    state.loading = false;
  }
}

async function refreshCounts() {
  try {
    const [all, fav, pin] = await Promise.all([
      fetch('/api/images?limit=1').then((r) => r.json()),
      fetch('/api/images?limit=1&favorite=true').then((r) => r.json()),
      fetch('/api/images?limit=1&pinned=true').then((r) => r.json()),
    ]);
    el.countAll.textContent = all.total || '';
    el.countFav.textContent = fav.total || '';
    el.countPin.textContent = pin.total || '';
  } catch (e) { /* cosmetic */ }
}

// ---------------------------------------------------------------- grid

function renderSkeleton() {
  el.content.innerHTML = `<div class="skeleton-grid">${'<div class="skeleton"></div>'.repeat(12)}</div>`;
}

function renderError(msg) {
  el.content.innerHTML = `
    <div class="state">
      <div class="state-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <path d="M12 8v5M12 16.5v.5"></path><circle cx="12" cy="12" r="9"></circle>
        </svg>
      </div>
      <div class="state-title">Couldn't load your library</div>
      <div class="state-body">${esc(msg)}. Try refreshing, or restart the app.</div>
    </div>`;
}

function stateBlock(title, body, withHelp) {
  const help = withHelp
    ? `<div class="state-actions">
         <button class="btn" id="stateRefresh">Check again</button>
         <button class="btn" id="stateSetup">Extension setup</button>
       </div>
       <div class="state-hint">
         Already generated some? Click the extension's toolbar icon in your
         browser and use <strong>Import NovelAI history now</strong> — it reads
         what NovelAI has already stored.
       </div>`
    : '';
  return `
    <div class="state">
      <div class="state-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="4" width="18" height="16" rx="2.5"></rect>
          <circle cx="8.5" cy="9.5" r="1.6"></circle><path d="M21 15l-5-4.5L7 20"></path>
        </svg>
      </div>
      <div class="state-title">${esc(title)}</div>
      <div class="state-body">${esc(body)}</div>
      ${help}
    </div>`;
}

function emptyState() {
  if (state.query) return stateBlock('No matches', `Nothing matched “${state.query}”. Try a shorter phrase, or a single tag.`);
  if (state.view === 'favorites') return stateBlock('No favorites yet', 'Open any image and hit Favorite to keep it here.');
  if (state.view === 'pinned') return stateBlock('Nothing pinned', 'Pinned images float to the top of every view.');
  if (state.folderId) return stateBlock('This folder is empty', 'Open an image and use Add to folder to file it here.');
  return stateBlock(
    'No images yet',
    'Generate something on NovelAI with the extension installed and it lands here automatically.',
    true
  );
}

/**
 * Reconcile the grid in place rather than rebuilding it.
 *
 * The background refresh runs every few seconds; replacing innerHTML each
 * time re-created every <img>, which made the whole gallery visibly blink
 * as the browser re-decoded images it already had. Instead, existing card
 * nodes are kept and reordered, so untouched images are never re-created
 * and nothing flickers.
 */
function render() {
  if (state.items.length === 0) {
    // Rewriting an identical empty state every few seconds is the same
    // flicker the grid used to have, so it's only rebuilt when what it
    // would say has actually changed.
    const key = `${state.view}|${state.folderId || ''}|${state.query}`;
    if (el.content.dataset.emptyKey !== key) {
      el.content.dataset.emptyKey = key;
      el.content.innerHTML = emptyState();
      const r = document.getElementById('stateRefresh');
      if (r) r.addEventListener('click', () => load({ reset: true }));
      const su = document.getElementById('stateSetup');
      if (su) su.addEventListener('click', openExtensionSetup);
    }
    el.countPill.textContent = '';
    return;
  }

  delete el.content.dataset.emptyKey;
  let grid = el.content.querySelector('.grid');
  if (!grid) {
    el.content.innerHTML = '';
    grid = document.createElement('div');
    grid.className = `grid layout-${state.settings.layout}`;
    el.content.appendChild(grid);
  }

  const existing = new Map();
  grid.querySelectorAll('.card').forEach((n) => existing.set(n.dataset.id, n));

  const wanted = new Set(state.items.map((r) => r.id));
  existing.forEach((node, id) => {
    if (!wanted.has(id)) node.remove();
  });

  let prev = null;
  for (const record of state.items) {
    let node = existing.get(record.id);
    if (node) {
      // Only touch the DOM if the badge state actually changed; the <img>
      // itself is deliberately left untouched.
      const wantBadges = `${record.pinned ? 'p' : ''}${record.favorite ? 'f' : ''}`;
      if (node.dataset.badges !== wantBadges) {
        const fresh = card(record);
        node.replaceWith(fresh);
        node = fresh;
      }
    } else {
      node = card(record);
    }

    const shouldFollow = prev ? prev.nextElementSibling : grid.firstElementChild;
    if (shouldFollow !== node) {
      grid.insertBefore(node, prev ? prev.nextElementSibling : grid.firstElementChild);
    }
    prev = node;
  }

  applyLayout();
  updateSelectionUI();

  // Load-more button lives outside the grid; refresh it separately.
  const oldMore = el.content.querySelector('.load-more-wrap');
  if (oldMore) oldMore.remove();
  if (state.offset < state.total) {
    const wrap = document.createElement('div');
    wrap.className = 'load-more-wrap';
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.textContent = `Load more (${state.total - state.offset} left)`;
    btn.addEventListener('click', () => load());
    wrap.appendChild(btn);
    el.content.appendChild(wrap);
  }

  el.countPill.textContent = `${state.total} image${state.total === 1 ? '' : 's'}`;
}

const ICONS = {
  pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4h6l-1 6 4 3v2H6v-2l4-3z"></path><path d="M12 15v5"></path></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 3.6l2.6 5.3 5.8.8-4.2 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.6 9.7l5.8-.8z"></path></svg>',
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16"></path><path d="M9.5 7V5h5v2"></path><path d="M6.5 7l1 12.5h9L17.5 7"></path><path d="M10.5 10.5v6M13.5 10.5v6"></path></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>',
};

function cardActionBtn(kind, title, onClick, active) {
  const b = document.createElement('button');
  b.className = `card-action ${kind}${active ? ' active' : ''}`;
  b.title = title;
  b.setAttribute('aria-label', title);
  b.innerHTML = ICONS[kind === 'delete' ? 'trash' : kind];
  b.addEventListener('click', (e) => {
    e.stopPropagation();
    e.preventDefault();
    onClick();
  });
  return b;
}

function card(record) {
  const div = document.createElement('div');
  div.className = 'card';
  div.dataset.id = record.id;
  div.dataset.badges = `${record.pinned ? 'p' : ''}${record.favorite ? 'f' : ''}`;
  div.draggable = true;

  const img = document.createElement('img');
  img.loading = 'lazy';
  img.draggable = false; // the card owns the drag, not the bare image
  img.src = `/api/images/${record.id}/file`;
  img.alt = record.meta?.prompt?.slice(0, 60) || '';
  div.appendChild(img);

  const overlay = document.createElement('div');
  overlay.className = 'card-overlay';
  if (record.meta?.prompt) {
    const p = document.createElement('div');
    p.className = 'card-prompt';
    p.textContent = record.meta.prompt;
    overlay.appendChild(p);
  }
  div.appendChild(overlay);

  // Text column, only visible in list layout.
  const info = document.createElement('div');
  info.className = 'card-info';
  const infoPrompt = document.createElement('div');
  infoPrompt.className = 'card-info-prompt';
  infoPrompt.textContent = record.meta?.prompt || record.filename;
  const infoMeta = document.createElement('div');
  infoMeta.className = 'card-info-meta';
  const m = record.meta || {};
  infoMeta.textContent = [
    m.model,
    m.width && m.height ? `${m.width} × ${m.height}` : null,
    m.seed !== undefined && m.seed !== null && m.seed !== '' ? `seed ${m.seed}` : null,
    new Date(record.addedAt).toLocaleDateString(),
  ].filter(Boolean).join('  ·  ');
  info.appendChild(infoPrompt);
  info.appendChild(infoMeta);
  div.appendChild(info);

  if (record.favorite || record.pinned) {
    const badges = document.createElement('div');
    badges.className = 'card-badges';
    if (record.pinned) badges.appendChild(badge('pin', '📌'));
    if (record.favorite) badges.appendChild(badge('star', '★'));
    div.appendChild(badges);
  }

  // Hover actions. Kept out of the click path for the card itself so a
  // stray click never deletes something.
  const actions = document.createElement('div');
  actions.className = 'card-actions';
  actions.appendChild(cardActionBtn('pin', record.pinned ? 'Unpin' : 'Pin',
    () => setFlag(record, 'pinned', !record.pinned), record.pinned));
  actions.appendChild(cardActionBtn('star', record.favorite ? 'Remove from favorites' : 'Favorite',
    () => setFlag(record, 'favorite', !record.favorite), record.favorite));
  actions.appendChild(cardActionBtn('delete', 'Delete image', () => deleteImages([record.id])));
  div.appendChild(actions);

  const check = document.createElement('button');
  check.className = 'card-check';
  check.title = 'Select';
  check.setAttribute('aria-label', 'Select image');
  check.innerHTML = ICONS.check;
  check.addEventListener('click', (e) => {
    e.stopPropagation();
    e.preventDefault();
    setSelectMode(true);
    toggleSelection(record.id, e.shiftKey);
  });
  div.appendChild(check);

  div.addEventListener('click', (e) => {
    // In select mode, or with a modifier held, clicking picks rather than opens.
    if (state.selectMode || e.ctrlKey || e.metaKey || e.shiftKey) {
      setSelectMode(true);
      toggleSelection(record.id, e.shiftKey);
      return;
    }
    selectRecord(record);
    openViewer(record);
  });

  div.addEventListener('dragstart', (e) => onCardDragStart(e, record));
  div.addEventListener('dragend', () => {
    document.querySelectorAll('.card.dragging').forEach((n) => n.classList.remove('dragging'));
    document.querySelectorAll('.drop-target').forEach((n) => n.classList.remove('drop-target'));
  });

  return div;
}

function badge(kind, glyph) {
  const b = document.createElement('div');
  b.className = `card-badge ${kind}`;
  b.textContent = glyph;
  return b;
}

// ---------------------------------------------------------------- layout

const GAP = 14;
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

function aspectOf(record) {
  const w = record?.meta?.width;
  const h = record?.meta?.height;
  if (w > 0 && h > 0) return w / h;
  return 1;
}

/**
 * Justified and waterfall need real geometry, so they're measured in JS and
 * written as inline transforms. Cards keep their document order either way,
 * which is what lets the flicker-free reconciliation above stay simple.
 */
function applyLayout() {
  const grid = el.content.querySelector('.grid');
  if (!grid) return;

  const mode = state.settings.layout;
  grid.className = `grid layout-${mode}`;

  const cards = Array.from(grid.children).filter((n) => n.classList.contains('card'));
  if (mode === 'grid' || mode === 'list') {
    grid.style.height = '';
    cards.forEach((c) => c.removeAttribute('style'));
    return;
  }

  const width = grid.clientWidth;
  if (width <= 0 || cards.length === 0) return;

  const byId = new Map(state.items.map((r) => [r.id, r]));
  const target = state.settings.cardSize || 190;
  if (mode === 'justified') layoutJustified(grid, cards, byId, width, target);
  else layoutWaterfall(grid, cards, byId, width, target);
}

function place(node, x, y, w, h) {
  node.style.position = 'absolute';
  node.style.left = '0';
  node.style.top = '0';
  node.style.width = `${Math.round(w)}px`;
  node.style.height = `${Math.round(h)}px`;
  node.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
}

function layoutJustified(grid, cards, byId, width, target) {
  let row = [];
  let sum = 0;
  let y = 0;

  const flush = (isLast) => {
    if (!row.length) return;
    const gaps = GAP * (row.length - 1);
    let h = (width - gaps) / sum;
    // A last row holding one wide image would otherwise stretch to a
    // full-bleed banner; hold it near the chosen size instead.
    if (isLast && h > target * 1.45) h = target;
    let x = 0;
    row.forEach((entry, i) => {
      let w = entry.aspect * h;
      if (i === row.length - 1 && !isLast) w = width - x; // absorb rounding
      place(entry.node, x, y, w, h);
      x += w + GAP;
    });
    y += h + GAP;
    row = [];
    sum = 0;
  };

  for (const node of cards) {
    const aspect = clamp(aspectOf(byId.get(node.dataset.id)), 0.3, 4.5);
    row.push({ node, aspect });
    sum += aspect;
    if (sum * target + GAP * (row.length - 1) >= width) flush(false);
  }
  flush(true);

  grid.style.height = `${Math.max(0, Math.round(y - GAP))}px`;
}

function layoutWaterfall(grid, cards, byId, width, target) {
  const cols = Math.max(1, Math.round((width + GAP) / (target + GAP)));
  const colW = (width - GAP * (cols - 1)) / cols;
  const heights = new Array(cols).fill(0);

  for (const node of cards) {
    const aspect = clamp(aspectOf(byId.get(node.dataset.id)), 0.25, 5);
    const h = colW / aspect;
    // Shortest column wins, so the order stays roughly left-to-right
    // instead of the column-major order CSS columns would give.
    let c = 0;
    for (let i = 1; i < cols; i++) {
      if (heights[i] < heights[c] - 0.5) c = i;
    }
    place(node, c * (colW + GAP), heights[c], colW, h);
    heights[c] += h + GAP;
  }

  grid.style.height = `${Math.max(0, Math.round(Math.max(...heights) - GAP))}px`;
}

let layoutTimer;
function scheduleLayout() {
  clearTimeout(layoutTimer);
  layoutTimer = setTimeout(applyLayout, 60);
}
new ResizeObserver(scheduleLayout).observe(el.content);

// ---------------------------------------------------------------- selection

function setSelectMode(on) {
  if (state.selectMode === on) return;
  state.selectMode = on;
  el.app.classList.toggle('select-mode', on);
  el.selectBtn.classList.toggle('active', on);
  if (!on) state.selection.clear();
  updateSelectionUI();
}

function toggleSelection(id, viaShift) {
  if (viaShift && state.anchorId) {
    const ids = state.items.map((r) => r.id);
    const a = ids.indexOf(state.anchorId);
    const b = ids.indexOf(id);
    if (a !== -1 && b !== -1) {
      const [lo, hi] = a < b ? [a, b] : [b, a];
      for (let i = lo; i <= hi; i++) state.selection.add(ids[i]);
      updateSelectionUI();
      return;
    }
  }
  if (state.selection.has(id)) state.selection.delete(id);
  else state.selection.add(id);
  state.anchorId = id;
  updateSelectionUI();
}

function updateSelectionUI() {
  const n = state.selection.size;
  el.content.querySelectorAll('.card').forEach((node) => {
    node.classList.toggle('selected', state.selection.has(node.dataset.id));
  });
  el.bulkbar.hidden = !state.selectMode && n === 0;
  el.bulkCount.textContent = n === 0
    ? 'Select images'
    : `${n} selected`;
  [el.bulkPin, el.bulkFav, el.bulkDelete, el.bulkFolderBtn].forEach((b) => { b.disabled = n === 0; });
  const allSelected = state.items.length > 0 && n >= state.items.length;
  el.bulkSelectAll.textContent = allSelected ? 'Select none' : 'Select all';
}

async function bulkRequest(body) {
  const res = await fetch('/api/images/bulk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`);
  return res.json();
}

function selectedIds() {
  return Array.from(state.selection);
}

async function bulkFlag(field, value) {
  const ids = selectedIds();
  if (!ids.length) return;
  try {
    await bulkRequest({ action: 'update', ids, [field]: value });
  } catch (e) {
    return toast('Could not save that change');
  }
  ids.forEach((id) => {
    const rec = state.items.find((r) => r.id === id);
    if (rec) rec[field] = value;
  });
  render();
  refreshCounts();
  toast(`${ids.length} image${ids.length === 1 ? '' : 's'} ${
    field === 'pinned' ? (value ? 'pinned' : 'unpinned') : (value ? 'favorited' : 'unfavorited')}`);
}

async function moveToFolder(ids, folderId, folderName) {
  if (!ids.length) return;
  try {
    await bulkRequest({ action: 'update', ids, addFolders: [folderId] });
  } catch (e) {
    return toast('Could not move those images');
  }
  toast(`${ids.length} image${ids.length === 1 ? '' : 's'} added to ${folderName}`);
  load({ reset: true, silent: true });
}

// ---------------------------------------------------------------- deleting

async function deleteImages(ids, { skipConfirm } = {}) {
  if (!ids.length) return;
  if (!skipConfirm) {
    const ok = await confirmDialog({
      title: ids.length === 1 ? 'Delete this image?' : `Delete ${ids.length} images?`,
      body: ids.length === 1
        ? 'The image file and its prompt metadata are removed from this gallery for good.'
        : `The ${ids.length} selected image files and their prompt metadata are removed from this gallery for good.`,
      confirmLabel: ids.length === 1 ? 'Delete image' : `Delete ${ids.length} images`,
    });
    if (!ok) return;
  }

  try {
    if (ids.length === 1) {
      const res = await fetch(`/api/images/${ids[0]}`, { method: 'DELETE' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
    } else {
      await bulkRequest({ action: 'delete', ids });
    }
  } catch (e) {
    return toast('Could not delete');
  }

  const gone = new Set(ids);
  state.items = state.items.filter((r) => r.id !== undefined && !gone.has(r.id));
  ids.forEach((id) => state.selection.delete(id));
  state.total = Math.max(0, state.total - ids.length);
  state.offset = Math.max(0, state.offset - ids.length);
  if (state.current && gone.has(state.current.id)) closeViewer();
  if (state.selected && gone.has(state.selected.id)) { state.selected = null; renderInspector(); }

  render();
  refreshCounts();
  toast(ids.length === 1 ? 'Image deleted' : `${ids.length} images deleted`);
}

async function clearGallery() {
  let total = state.total;
  try {
    total = (await fetch('/api/images?limit=1').then((r) => r.json())).total;
  } catch (e) { /* fall back to what's on screen */ }

  if (!total) return toast('The gallery is already empty');

  const ok = await confirmDialog({
    title: 'Clear the whole gallery?',
    body: `All <strong>${total}</strong> image${total === 1 ? '' : 's'} and their prompt
           metadata are permanently deleted from this gallery. Your folders, themes and
           settings are kept, and any copies you saved elsewhere on your PC are untouched.
           <br><br>This cannot be undone.`,
    confirmLabel: `Delete all ${total} images`,
  });
  if (!ok) return;

  try {
    const res = await fetch('/api/images', { method: 'DELETE' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  } catch (e) {
    return toast('Could not clear the gallery');
  }

  state.selection.clear();
  setSelectMode(false);
  closeViewer();
  state.selected = null;
  renderInspector();
  el.settingsModal.hidden = true;
  await load({ reset: true });
  refreshCounts();
  toast('Gallery cleared');
}

/* ---------------------------------------------------------------- context menu

   One menu, built from whatever was right-clicked. Text inputs are left
   alone so the browser's own copy/paste menu still works where it's the
   useful one.
*/

let ctxOpen = false;

function closeContextMenu() {
  if (!ctxOpen) return;
  ctxOpen = false;
  el.ctxMenu.hidden = true;
  el.ctxMenu.innerHTML = '';
}

/**
 * items: [{ label, detail, danger, disabled, icon, action }] or 'sep'.
 * A `submenu` function returns a fresh item list, drilled into in place -
 * simpler and more reliable than a flyout, and it can't open off-screen.
 */
function openContextMenu(x, y, items, title) {
  el.ctxMenu.innerHTML = '';
  if (title) {
    const h = document.createElement('div');
    h.className = 'ctx-title';
    h.textContent = title;
    el.ctxMenu.appendChild(h);
  }

  for (const item of items) {
    if (item === 'sep') {
      const sep = document.createElement('div');
      sep.className = 'ctx-sep';
      el.ctxMenu.appendChild(sep);
      continue;
    }
    const btn = document.createElement('button');
    btn.className = `ctx-item${item.danger ? ' danger' : ''}${item.back ? ' back' : ''}`;
    btn.disabled = !!item.disabled;
    btn.innerHTML = `
      <span class="ctx-icon">${item.icon || ''}</span>
      <span class="ctx-label">${esc(item.label)}</span>
      ${item.detail ? `<span class="ctx-detail">${esc(item.detail)}</span>` : ''}
      ${item.submenu ? '<span class="ctx-arrow">›</span>' : ''}`;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (item.disabled) return;
      if (item.submenu) {
        const { items: sub, title: subTitle } = item.submenu();
        openContextMenu(x, y, sub, subTitle);
        return;
      }
      closeContextMenu();
      item.action?.();
    });
    el.ctxMenu.appendChild(btn);
  }

  // Show it before measuring, then keep it inside the window.
  el.ctxMenu.hidden = false;
  ctxOpen = true;
  const rect = el.ctxMenu.getBoundingClientRect();
  const left = Math.max(6, Math.min(x, window.innerWidth - rect.width - 6));
  const top = Math.max(6, Math.min(y, window.innerHeight - rect.height - 6));
  el.ctxMenu.style.left = `${Math.round(left)}px`;
  el.ctxMenu.style.top = `${Math.round(top)}px`;
}

const CTX_ICONS = {
  open: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2.5"></rect><circle cx="8.5" cy="9.5" r="1.6"></circle><path d="M21 15l-5-4.5L7 20"></path></svg>',
  folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h3.5l2 2.5H19a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>',
  select: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"></rect><path d="M8 12.5l2.8 2.8L16.5 9"></path></svg>',
  reuse: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"></path><path d="M21 3v6h-6"></path></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"></rect><path d="M5 15V5a2 2 0 0 1 2-2h8"></path></svg>',
  explorer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h3.5l2 2.5H19a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><path d="M12 15V9.5"></path><path d="M9.5 12L12 9.5l2.5 2.5"></path></svg>',
  import: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4"></path><path d="M8 8l4-4 4 4"></path><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"></path></svg>',
  refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-2.64-6.36"></path><path d="M21 3v6h-6"></path></svg>',
  trash: ICONS.trash,
  star: ICONS.star,
  pin: ICONS.pin,
};

/** The folder list, as menu items that file the given images. */
function folderSubmenu(ids) {
  return () => {
    const items = [{ label: 'Back', back: true, icon: '‹', submenu: () => imageMenu(ids) }];
    if (state.folders.length === 0) {
      items.push({ label: 'No folders yet', disabled: true });
    } else {
      for (const f of state.folders) {
        items.push({
          label: f.name,
          icon: CTX_ICONS.folder,
          action: () => moveToFolder(ids, f.id, f.name),
        });
      }
    }
    items.push('sep', {
      label: 'New folder…',
      icon: '+',
      action: async () => {
        const name = prompt('Folder name');
        if (!name || !name.trim()) return;
        const folder = await createFolder(name);
        if (folder) moveToFolder(ids, folder.id, folder.name);
      },
    });
    return { items, title: ids.length === 1 ? 'Move to folder' : `Move ${ids.length} images to` };
  };
}

function imageMenu(ids) {
  const many = ids.length > 1;
  const record = state.items.find((r) => r.id === ids[0]);
  const noun = many ? `${ids.length} images` : 'image';

  const items = [];
  if (!many && record) {
    items.push({
      label: 'Open',
      icon: CTX_ICONS.open,
      action: () => { selectRecord(record); openViewer(record); },
    });
  }
  items.push({
    label: state.selection.has(ids[0]) && many ? 'Keep selection' : `Select ${many ? 'these' : 'this'}`,
    icon: CTX_ICONS.select,
    action: () => {
      setSelectMode(true);
      ids.forEach((id) => state.selection.add(id));
      updateSelectionUI();
    },
  });
  items.push('sep');
  items.push({
    label: `Move ${noun} to folder`,
    icon: CTX_ICONS.folder,
    submenu: folderSubmenu(ids),
  });

  const allPinned = ids.every((id) => state.items.find((r) => r.id === id)?.pinned);
  const allFav = ids.every((id) => state.items.find((r) => r.id === id)?.favorite);
  items.push({
    label: allPinned ? `Unpin ${noun}` : `Pin ${noun}`,
    icon: CTX_ICONS.pin,
    action: () => (many
      ? bulkFlag('pinned', !allPinned)
      : setFlag(record, 'pinned', !record.pinned)),
  });
  items.push({
    label: allFav ? `Remove ${noun} from favorites` : `Favorite ${noun}`,
    icon: CTX_ICONS.star,
    action: () => (many
      ? bulkFlag('favorite', !allFav)
      : setFlag(record, 'favorite', !record.favorite)),
  });

  if (!many && record) {
    items.push('sep');
    items.push({
      label: 'Reuse prompt in NovelAI',
      icon: CTX_ICONS.reuse,
      action: () => {
        selectRecord(record);
        openViewer(record);
        setTimeout(() => el.detailsBody.querySelector('#reuseBtn')?.click(), 150);
      },
    });
    items.push({
      label: 'Copy prompt',
      icon: CTX_ICONS.copy,
      disabled: !record.meta?.prompt,
      action: () => navigator.clipboard.writeText(record.meta?.prompt || '')
        .then(() => toast('Prompt copied')).catch(() => toast('Could not copy')),
    });
    items.push({
      label: 'Open in folder',
      icon: CTX_ICONS.explorer,
      action: () => revealImage(record),
    });
  }

  items.push('sep');
  items.push({
    label: many ? `Delete ${ids.length} images` : 'Delete image',
    icon: CTX_ICONS.trash,
    danger: true,
    action: () => deleteImages(ids),
  });
  return items;
}

function folderRowMenu(folder) {
  return [
    { label: 'Open folder', icon: CTX_ICONS.folder, action: () => selectView('folder', folder.id) },
    'sep',
    {
      label: 'Delete folder',
      detail: 'images are kept',
      icon: CTX_ICONS.trash,
      danger: true,
      action: async () => {
        const ok = await confirmDialog({
          title: `Delete the folder “${folder.name}”?`,
          body: 'The folder is removed and its images stop being filed under it. The images themselves are not deleted.',
          confirmLabel: 'Delete folder',
        });
        if (!ok) return;
        const res = await fetch(`/api/folders/${folder.id}`, { method: 'DELETE' });
        if (!res.ok) return toast('Could not delete that folder');
        if (state.folderId === folder.id) selectView('all');
        else loadFolders();
        toast('Folder deleted');
      },
    },
  ];
}

function galleryMenu() {
  return [
    { label: 'Import images…', icon: CTX_ICONS.import, action: () => el.importInput.click() },
    { label: 'Refresh', icon: CTX_ICONS.refresh, action: () => { load({ reset: true }); loadFolders(); } },
    'sep',
    {
      label: 'Select all',
      icon: CTX_ICONS.select,
      disabled: state.items.length === 0,
      action: () => {
        setSelectMode(true);
        state.items.forEach((r) => state.selection.add(r.id));
        updateSelectionUI();
      },
    },
    {
      label: 'New folder…',
      icon: CTX_ICONS.folder,
      action: async () => { if (await createFolder(prompt('Folder name') || '')) toast('Folder created'); },
    },
  ];
}

document.addEventListener('contextmenu', (e) => {
  // Leave text alone: the browser's own menu is the useful one there.
  if (e.target.closest('input, textarea, [contenteditable="true"]')) return;
  // Modals get the default menu too, rather than a gallery menu behind them.
  if (e.target.closest('.modal:not([hidden])')) return;

  const card = e.target.closest('.card');
  if (card) {
    e.preventDefault();
    const id = card.dataset.id;
    // Right-clicking inside a selection acts on the whole selection;
    // right-clicking outside one acts on just that image.
    const ids = state.selection.has(id) && state.selection.size > 1
      ? selectedIds()
      : [id];
    openContextMenu(e.clientX, e.clientY, imageMenu(ids),
      ids.length > 1 ? `${ids.length} images` : null);
    return;
  }

  const viewerImg = e.target.closest('#viewerImg, .inspector-thumb');
  if (viewerImg) {
    const record = state.current || state.selected;
    if (record) {
      e.preventDefault();
      openContextMenu(e.clientX, e.clientY, imageMenu([record.id]));
    }
    return;
  }

  const folderRow = e.target.closest('#folderList .nav-item');
  if (folderRow) {
    const folder = state.folders.find((f) => f.name === folderRow.querySelector('.nav-label')?.textContent);
    if (folder) {
      e.preventDefault();
      openContextMenu(e.clientX, e.clientY, folderRowMenu(folder), folder.name);
    }
    return;
  }

  if (e.target.closest('.content')) {
    e.preventDefault();
    openContextMenu(e.clientX, e.clientY, galleryMenu());
  }
});

document.addEventListener('click', closeContextMenu);
document.addEventListener('scroll', closeContextMenu, true);
window.addEventListener('blur', closeContextMenu);
window.addEventListener('resize', closeContextMenu);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeContextMenu(); }, true);

// ---------------------------------------------------------------- drag to folder

const DRAG_TYPE = 'application/x-novelai-gallery-ids';

function onCardDragStart(e, record) {
  // Dragging a card that's part of the selection drags the whole selection;
  // dragging anything else drags just that image.
  const ids = state.selection.has(record.id) && state.selection.size > 0
    ? selectedIds()
    : [record.id];

  try {
    e.dataTransfer.setData(DRAG_TYPE, JSON.stringify(ids));
    e.dataTransfer.setData('text/plain', ids.join(','));
  } catch (err) { /* nothing usable to drag */ }
  e.dataTransfer.effectAllowed = 'copy';

  el.app.classList.add('dragging-images');
  ids.forEach((id) => {
    const node = el.content.querySelector(`.card[data-id="${id}"]`);
    if (node) node.classList.add('dragging');
  });

  if (ids.length > 1) {
    const ghost = document.createElement('div');
    ghost.className = 'drag-ghost';
    ghost.textContent = `${ids.length} images`;
    document.body.appendChild(ghost);
    e.dataTransfer.setDragImage(ghost, 12, 12);
    setTimeout(() => ghost.remove(), 0);
  }
}

document.addEventListener('dragend', () => el.app.classList.remove('dragging-images'));

/** Wire a sidebar row so images can be dropped onto it. */
function wireImageDropTarget(node, handler) {
  node.addEventListener('dragover', (e) => {
    if (!Array.from(e.dataTransfer.types || []).includes(DRAG_TYPE)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    node.classList.add('drop-target');
  });
  node.addEventListener('dragleave', () => node.classList.remove('drop-target'));
  node.addEventListener('drop', (e) => {
    if (!Array.from(e.dataTransfer.types || []).includes(DRAG_TYPE)) return;
    e.preventDefault();
    e.stopPropagation();
    node.classList.remove('drop-target');
    el.app.classList.remove('dragging-images');
    let ids = [];
    try {
      ids = JSON.parse(e.dataTransfer.getData(DRAG_TYPE) || '[]');
    } catch (err) { /* malformed drag payload */ }
    if (ids.length) handler(ids);
  });
}

// ---------------------------------------------------------------- metadata rendering

function tagChip(tag, negative) {
  const weighted = window.PromptModel.isWeighted(tag);
  return `<button class="tag${weighted ? ' weighted' : ''}${negative ? ' negative' : ''}" data-tag="${esc(tag)}">${esc(tag)}</button>`;
}

/**
 * Sections start collapsed. An image can carry four of them and 100+ tags;
 * expanded by default that buries the generation settings under a wall of
 * chips you have to scroll past every time. The headers still show a count,
 * so nothing is hidden - it just isn't shouted.
 */
function isSectionCollapsed(id) {
  return state.collapsed[id] !== false;
}

function sectionHtml(section) {
  const collapsed = isSectionCollapsed(section.id) ? ' collapsed' : '';
  const negative = section.kind === 'negative';

  let count = 0;
  let body = '';

  if (section.characters) {
    count = section.characters.reduce((n, c) => n + c.tags.length, 0);
    body = section.characters.map((c) => `
      <div class="char-block">
        <div class="char-label"><span class="char-dot"></span>${esc(c.label)}</div>
        <div class="tags">${c.tags.map((t) => tagChip(t, negative)).join('')}</div>
      </div>`).join('');
  } else {
    count = section.tags.length;
    body = `<div class="tags">${section.tags.map((t) => tagChip(t, negative)).join('')}</div>`;
  }

  return `
    <div class="section${collapsed}" data-section="${section.id}">
      <button class="section-head">
        <svg class="section-chevron" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
          <path d="M6 9l6 6 6-6"></path>
        </svg>
        <span class="section-name">${esc(section.name)}</span>
        <span class="section-tally">${count}</span>
      </button>
      <div class="section-body">
        ${body}
        <button class="raw-toggle" data-raw="${section.id}">Show raw text</button>
        <div class="raw-text" data-raw-for="${section.id}" hidden>${esc(section.raw)}</div>
      </div>
    </div>`;
}

function specsHtml(m) {
  const specs = [
    ['Model', m.model], ['Sampler', m.sampler], ['Steps', m.steps], ['Guidance', m.scale],
    ['Seed', m.seed], ['Strength', m.strength], ['Noise', m.noise],
    ['Size', m.width && m.height ? `${m.width} × ${m.height}` : null],
  ].filter(([, v]) => v !== null && v !== undefined && v !== '');
  if (!specs.length) return '';
  return `
    <div class="field">
      <div class="field-label">Generation</div>
      <div class="spec-grid">
        ${specs.map(([k, v]) => `<div class="spec"><div class="spec-key">${esc(k)}</div><div class="spec-val">${esc(v)}</div></div>`).join('')}
      </div>
    </div>`;
}

/**
 * The same sections as plain text in a box, for people who'd rather copy a
 * prompt straight out than read it as chips.
 */
function rawSectionHtml(section) {
  return `
    <div class="raw-section" data-section="${section.id}">
      <div class="raw-head">
        <span class="raw-name${section.kind === 'negative' ? ' negative' : ''}">${esc(section.name)}</span>
        <button class="raw-copy" data-copy="${section.id}">Copy</button>
      </div>
      <textarea class="raw-box" readonly spellcheck="false"
        data-raw-box="${section.id}">${esc(section.raw)}</textarea>
    </div>`;
}

/** Renders the shared metadata body used by both the panel and the modal. */
function renderMetaInto(container, record, { showReuse } = {}) {
  const m = record.meta || {};
  const sections = window.PromptModel.buildSections(m);
  const raw = state.settings.metaView === 'raw';

  container.innerHTML = `
    ${showReuse ? `
      <div class="reuse-row">
        <button class="btn primary" id="reuseBtn">Reuse prompt in NovelAI</button>
        <button class="btn" id="revealBtn" title="Show this file in File Explorer">Open in folder</button>
      </div>
      <div class="hint" id="reuseHint">Hands this image to an open NovelAI tab, the same as dragging the file in — NovelAI reads the prompt and settings back out of it.</div>` : ''}
    ${sections.map(raw ? rawSectionHtml : sectionHtml).join('')}
    ${specsHtml(m)}
    <div class="field">
      <div class="field-label">Added</div>
      <div class="spec-val">${esc(new Date(record.addedAt).toLocaleString())}</div>
    </div>
    ${imagePathOf(record) ? `
      <div class="field">
        <div class="field-label">File on disk</div>
        <div class="file-path" id="filePath" title="${esc(imagePathOf(record))}">${esc(imagePathOf(record))}</div>
      </div>` : ''}`;

  // Collapse / expand
  container.querySelectorAll('.section-head').forEach((head) => {
    head.addEventListener('click', () => {
      const sec = head.closest('.section');
      const id = sec.dataset.section;
      state.collapsed[id] = !isSectionCollapsed(id);
      sec.classList.toggle('collapsed', isSectionCollapsed(id));
    });
  });

  // Raw text reveal
  container.querySelectorAll('.raw-toggle').forEach((btn) => {
    btn.addEventListener('click', () => {
      const target = container.querySelector(`[data-raw-for="${btn.dataset.raw}"]`);
      const nowHidden = !target.hidden;
      target.hidden = nowHidden;
      btn.textContent = nowHidden ? 'Show raw text' : 'Hide raw text';
    });
  });

  // Raw view: copy buttons, and boxes that grow to their content.
  // Grow to the text, but only so far: a long prompt should scroll inside
  // its box rather than pushing everything else off the panel. The box is
  // still resizable by hand.
  container.querySelectorAll('.raw-box').forEach((box) => {
    box.style.height = 'auto';
    box.style.height = `${Math.min(box.scrollHeight + 2, 168)}px`;
    box.addEventListener('focus', () => box.select());
  });
  container.querySelectorAll('.raw-copy').forEach((btn) => {
    btn.addEventListener('click', () => {
      const box = container.querySelector(`[data-raw-box="${btn.dataset.copy}"]`);
      if (!box) return;
      navigator.clipboard.writeText(box.value).then(() => {
        btn.textContent = 'Copied';
        setTimeout(() => (btn.textContent = 'Copy'), 1300);
      }).catch(() => {
        box.select();
        toast('Press Ctrl+C to copy');
      });
    });
  });

  const reuseBtn = container.querySelector('#reuseBtn');
  if (reuseBtn) reuseBtn.addEventListener('click', () => reusePrompt(record, container));

  const revealBtn = container.querySelector('#revealBtn');
  if (revealBtn) revealBtn.addEventListener('click', () => revealImage(record, revealBtn));

  const pathEl = container.querySelector('#filePath');
  if (pathEl) {
    pathEl.addEventListener('click', () => {
      navigator.clipboard.writeText(pathEl.textContent).then(() => toast('Path copied')).catch(() => {});
    });
  }

  // Click a tag to search for it
  container.querySelectorAll('.tag').forEach((t) => {
    t.addEventListener('click', () => {
      el.search.value = t.dataset.tag;
      el.searchClear.classList.add('visible');
      state.query = t.dataset.tag;
      closeViewer();
      load({ reset: true });
    });
  });
}

/**
 * Ask the extension to hand this image to NovelAI.
 *
 * The gallery can't message the extension directly, so it posts the
 * request to the app, which the extension is long-polling. We then poll
 * for the outcome so the button can report what actually happened rather
 * than just claiming success.
 */
async function reusePrompt(record, container) {
  const btn = container.querySelector('#reuseBtn');
  const hint = container.querySelector('#reuseHint');
  if (!btn) return;

  const setHint = (text, kind) => {
    if (!hint) return;
    hint.textContent = text;
    hint.className = `hint${kind ? ' ' + kind : ''}`;
  };

  btn.disabled = true;
  btn.textContent = 'Sending…';
  setHint('Looking for an open NovelAI tab…');

  try {
    const res = await fetch('/api/reuse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: record.id }),
    });
    if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || `HTTP ${res.status}`);

    // Wait for the extension to report back. The drop routine deliberately
    // takes a moment - it has to let the page react to the drag before it
    // lets go - so this window is generous.
    const deadline = Date.now() + 25000;
    let final = null;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 500));
      const st = await fetch('/api/reuse/status').then((r) => r.json()).catch(() => null);
      if (st && st.id === record.id && st.state && st.state !== 'pending') {
        final = st;
        break;
      }
    }

    if (!final) {
      setHint(
        'No answer from the extension. Check it\'s installed and that a NovelAI tab is open.',
        'warn'
      );
      toast('No response from the extension');
    } else if (final.state === 'delivered') {
      setHint('Sent to NovelAI — switch to that tab.', 'ok');
      toast('Sent to NovelAI');
    } else if (final.state === 'no-tab') {
      setHint('No NovelAI tab is open. Open NovelAI, then try again.', 'warn');
      toast('No NovelAI tab open');
    } else {
      setHint(final.message || 'NovelAI did not accept the image.', 'warn');
      toast('Could not hand it to NovelAI');
    }
  } catch (err) {
    setHint('Could not send: ' + err.message, 'warn');
    toast('Reuse failed');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Reuse prompt in NovelAI';
  }
}

// ---------------------------------------------------------------- inspector

function selectRecord(record) {
  state.selected = record;
  renderInspector();
}

function renderInspector() {
  const r = state.selected;
  if (!r) {
    el.inspectorBody.innerHTML = `<div class="empty-note">Select an image to see its prompt and settings here.</div>`;
    return;
  }
  el.inspectorBody.innerHTML = `<img class="inspector-thumb" id="inspectorThumb" src="/api/images/${r.id}/file" alt="" />
    <div id="inspectorMeta"></div>`;
  el.inspectorBody.querySelector('#inspectorThumb').addEventListener('click', () => openViewer(r));
  renderMetaInto(el.inspectorBody.querySelector('#inspectorMeta'), r, { showReuse: false });
}

function toggleInspector(force) {
  const open = force !== undefined ? force : !state.settings.inspectorOpen;
  saveSettings({ inspectorOpen: open });
  if (open) renderInspector();
}

/* ---------------------------------------------------------------- full size

   The large view is sized to fit alongside the metadata panel, which is
   the right default but no good for actually looking at detail. This is
   the whole window, the image at any zoom you like, and a way back.
*/

const zoom = {
  scale: 1,
  minScale: 0.05,
  maxScale: 8,
  x: 0,
  y: 0,
  fit: true,
  dragging: false,
  startX: 0,
  startY: 0,
};

function fitScale() {
  const c = el.zoomCanvas.getBoundingClientRect();
  const nw = el.zoomImg.naturalWidth;
  const nh = el.zoomImg.naturalHeight;
  if (!nw || !nh || !c.width || !c.height) return 1;
  // Never upscale to fill: "fit" means the whole picture, not a blown-up
  // version of a small one.
  return Math.min(1, Math.min((c.width - 48) / nw, (c.height - 48) / nh));
}

function applyZoom() {
  el.zoomImg.style.transform =
    `translate(calc(-50% + ${zoom.x}px), calc(-50% + ${zoom.y}px)) scale(${zoom.scale})`;
  el.zoomLevel.textContent = zoom.fit ? 'Fit' : `${Math.round(zoom.scale * 100)}%`;
  el.zoomCanvas.classList.toggle('grabbable', zoom.scale > fitScale() + 0.001);
}

function setZoom(scale, originX, originY) {
  const next = Math.min(zoom.maxScale, Math.max(zoom.minScale, scale));
  if (originX !== undefined) {
    // Keep whatever is under the cursor under the cursor.
    const c = el.zoomCanvas.getBoundingClientRect();
    const cx = originX - (c.left + c.width / 2);
    const cy = originY - (c.top + c.height / 2);
    const ratio = next / zoom.scale;
    zoom.x = cx - (cx - zoom.x) * ratio;
    zoom.y = cy - (cy - zoom.y) * ratio;
  }
  zoom.scale = next;
  zoom.fit = Math.abs(next - fitScale()) < 0.001;
  applyZoom();
}

function resetZoomToFit() {
  zoom.scale = fitScale();
  zoom.x = 0;
  zoom.y = 0;
  zoom.fit = true;
  applyZoom();
}

function openZoomView(record) {
  const r = record || state.current;
  if (!r) return;
  el.zoomName.textContent = r.meta?.prompt
    ? r.meta.prompt.slice(0, 90) + (r.meta.prompt.length > 90 ? '…' : '')
    : r.filename;
  el.zoomView.hidden = false;
  el.zoomHint.classList.remove('faded');
  clearTimeout(openZoomView.hintTimer);
  openZoomView.hintTimer = setTimeout(() => el.zoomHint.classList.add('faded'), 2600);

  const show = () => resetZoomToFit();
  if (el.zoomImg.dataset.id === r.id && el.zoomImg.complete) {
    show();
  } else {
    el.zoomImg.dataset.id = r.id;
    el.zoomImg.src = `/api/images/${r.id}/file`;
    if (el.zoomImg.complete) show();
    else el.zoomImg.addEventListener('load', show, { once: true });
  }
}

function closeZoomView() {
  el.zoomView.hidden = true;
}

el.expandBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  openZoomView(state.current);
});
el.zoomBack.addEventListener('click', closeZoomView);
el.zoomIn.addEventListener('click', () => setZoom(zoom.scale * 1.25));
el.zoomOut.addEventListener('click', () => setZoom(zoom.scale / 1.25));
el.zoomLevel.addEventListener('click', () => {
  if (zoom.fit) setZoom(1);
  else resetZoomToFit();
});

el.zoomCanvas.addEventListener('wheel', (e) => {
  e.preventDefault();
  const factor = e.deltaY < 0 ? 1.16 : 1 / 1.16;
  setZoom(zoom.scale * factor, e.clientX, e.clientY);
}, { passive: false });

el.zoomCanvas.addEventListener('dblclick', (e) => {
  if (zoom.fit) setZoom(1, e.clientX, e.clientY);
  else resetZoomToFit();
});

el.zoomCanvas.addEventListener('pointerdown', (e) => {
  if (e.button !== 0) return;
  zoom.dragging = true;
  zoom.startX = e.clientX - zoom.x;
  zoom.startY = e.clientY - zoom.y;
  el.zoomCanvas.setPointerCapture(e.pointerId);
  el.zoomCanvas.classList.add('grabbing');
});
el.zoomCanvas.addEventListener('pointermove', (e) => {
  if (!zoom.dragging) return;
  zoom.x = e.clientX - zoom.startX;
  zoom.y = e.clientY - zoom.startY;
  zoom.fit = false;
  applyZoom();
});
const endDrag = () => {
  zoom.dragging = false;
  el.zoomCanvas.classList.remove('grabbing');
};
el.zoomCanvas.addEventListener('pointerup', endDrag);
el.zoomCanvas.addEventListener('pointercancel', endDrag);

window.addEventListener('resize', () => { if (!el.zoomView.hidden && zoom.fit) resetZoomToFit(); });

// ---------------------------------------------------------------- lightbox

const DETAILS_W = 384;   // the fixed metadata column, matches styles.css
const VIEWER_PAD = 40;   // .viewer padding, both sides

/**
 * Size the large view to the picture.
 *
 * The image is never cropped or upscaled; this only trims the window round
 * it, so a tall image doesn't sit marooned in a wide black box and a wide
 * one doesn't get a letterbox it didn't need.
 */
function fitViewer() {
  const panel = el.lightbox.querySelector('.lightbox-panel');
  if (!panel || el.lightbox.hidden) return;

  panel.style.width = '';
  // Below this the panel stacks vertically and the width is the window's.
  if (window.innerWidth <= 1000) return;

  const nw = el.viewerImg.naturalWidth;
  const nh = el.viewerImg.naturalHeight;
  if (!nw || !nh) return;

  const maxPanelW = Math.min(1240, window.innerWidth - 56);
  const availH = panel.getBoundingClientRect().height - VIEWER_PAD;
  if (availH <= 0) return;

  // Width the image wants at full height, clamped so the details column
  // always fits and the viewer never collapses to a sliver.
  const wanted = (nw / nh) * availH;
  const viewerW = Math.min(Math.max(wanted, 320), maxPanelW - DETAILS_W - VIEWER_PAD);
  panel.style.width = `${Math.round(viewerW + VIEWER_PAD + DETAILS_W)}px`;
}

function openViewer(record) {
  state.current = record;
  el.viewerImg.src = `/api/images/${record.id}/file`;
  el.viewerImg.alt = record.meta?.prompt || '';
  el.lightbox.hidden = false;
  renderDetails();
  // Natural dimensions are known from the PNG header, so the window can be
  // sized before the pixels arrive - no visible resize once it decodes.
  const m = record.meta || {};
  if (m.width > 0 && m.height > 0) {
    const panel = el.lightbox.querySelector('.lightbox-panel');
    const maxPanelW = Math.min(1240, window.innerWidth - 56);
    const availH = panel.getBoundingClientRect().height - VIEWER_PAD;
    if (window.innerWidth > 1000 && availH > 0) {
      const viewerW = Math.min(
        Math.max((m.width / m.height) * availH, 320),
        maxPanelW - DETAILS_W - VIEWER_PAD
      );
      panel.style.width = `${Math.round(viewerW + VIEWER_PAD + DETAILS_W)}px`;
    }
  }
  if (el.viewerImg.complete) fitViewer();
}

el.viewerImg.addEventListener('load', fitViewer);
window.addEventListener('resize', () => { if (!el.lightbox.hidden) fitViewer(); });

function closeViewer() {
  closeZoomView();
  el.lightbox.hidden = true;
  el.viewerImg.src = '';
  const panel = el.lightbox.querySelector('.lightbox-panel');
  if (panel) panel.style.width = '';
  state.current = null;
}

function renderDetails() {
  const r = state.current;
  if (!r) return;
  el.favBtn.textContent = r.favorite ? '★ Favorited' : '☆ Favorite';
  el.favBtn.classList.toggle('active', !!r.favorite);
  el.pinBtn.textContent = r.pinned ? '📌 Pinned' : 'Pin';
  el.pinBtn.classList.toggle('active', !!r.pinned);
  renderMetaInto(el.detailsBody, r, { showReuse: true });
}

async function setFlag(record, fieldName, value) {
  const r = record;
  if (!r) return;
  const res = await fetch(`/api/images/${r.id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ [fieldName]: value }),
  });
  if (!res.ok) return toast('Could not save that change');
  const updated = await res.json();
  r[fieldName] = updated[fieldName];

  const idx = state.items.findIndex((x) => x.id === r.id);
  if (idx !== -1) state.items[idx] = r;

  if (state.current && state.current.id === r.id) renderDetails();
  refreshCounts();

  const node = el.content.querySelector(`.card[data-id="${r.id}"]`);
  if (node) {
    const fresh = card(r);
    // Keep the geometry the layout engine already computed, so swapping a
    // single card never shifts the rest of the gallery.
    fresh.setAttribute('style', node.getAttribute('style') || '');
    fresh.classList.toggle('selected', state.selection.has(r.id));
    node.replaceWith(fresh);
  }

  toast(fieldName === 'favorite'
    ? (r.favorite ? 'Added to favorites' : 'Removed from favorites')
    : (r.pinned ? 'Pinned' : 'Unpinned'));
}

function toggle(fieldName) {
  const r = state.current || state.selected;
  if (!r) return;
  return setFlag(r, fieldName, !r[fieldName]);
}

// ---------------------------------------------------------------- manual import

/**
 * Import PNGs the user picks or drags in. Goes through exactly the same
 * ingest path as the extension, so embedded prompt metadata is read the
 * same way; non-PNG or metadata-less files are reported rather than
 * silently dropped.
 */
async function importFiles(fileList) {
  const files = Array.from(fileList || []).filter((f) => /\.png$/i.test(f.name) || f.type === 'image/png');
  if (files.length === 0) {
    toast('Only PNG files can be imported');
    return;
  }

  let added = 0;
  let duplicate = 0;
  let failed = 0;

  toast(`Importing ${files.length} file${files.length === 1 ? '' : 's'}…`);

  for (const file of files) {
    const form = new FormData();
    form.append('file', file, file.name);
    form.append('source', JSON.stringify({ url: 'manual-import', capturedBy: 'manual-import' }));
    try {
      const res = await fetch('/api/images', { method: 'POST', body: form });
      if (!res.ok) { failed++; continue; }
      const body = await res.json();
      if (body.deduped) duplicate++;
      else added++;
    } catch (e) {
      failed++;
    }
  }

  const parts = [];
  if (added) parts.push(`${added} imported`);
  if (duplicate) parts.push(`${duplicate} already in the gallery`);
  if (failed) parts.push(`${failed} failed`);
  toast(parts.join(' · ') || 'Nothing imported');
  load({ reset: true });
}

el.importBtn.addEventListener('click', () => el.importInput.click());
el.importInput.addEventListener('change', () => {
  importFiles(el.importInput.files);
  el.importInput.value = ''; // let the same file be picked again later
});

// Whole-window drag and drop.
let dragDepth = 0;
window.addEventListener('dragenter', (e) => {
  if (!Array.from(e.dataTransfer?.types || []).includes('Files')) return;
  dragDepth++;
  el.dropzone.hidden = false;
});
window.addEventListener('dragover', (e) => {
  if (Array.from(e.dataTransfer?.types || []).includes('Files')) e.preventDefault();
});
window.addEventListener('dragleave', () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) el.dropzone.hidden = true;
});
window.addEventListener('drop', (e) => {
  if (!Array.from(e.dataTransfer?.types || []).includes('Files')) return;
  e.preventDefault();
  dragDepth = 0;
  el.dropzone.hidden = true;
  importFiles(e.dataTransfer.files);
});

// ---------------------------------------------------------------- folders

async function loadFolders() {
  try {
    const folders = await fetch('/api/folders').then((r) => r.json());
    state.folders = folders;
    el.folderList.innerHTML = '';
    if (folders.length === 0) {
      el.folderList.innerHTML =
        '<div class="empty-note">No folders yet. Make one, then drag images onto it.</div>';
      return;
    }
    folders.forEach((f) => {
      const btn = document.createElement('button');
      btn.className = `nav-item${state.folderId === f.id ? ' active' : ''}`;
      btn.innerHTML = `
        <span class="nav-icon">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h3.5l2 2.5H19a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </span>
        <span class="nav-label">${esc(f.name)}</span>`;
      btn.addEventListener('click', () => selectView('folder', f.id));
      // Dropping images on a folder files them there.
      wireImageDropTarget(btn, (ids) => moveToFolder(ids, f.id, f.name));
      el.folderList.appendChild(btn);
    });
  } catch (e) { /* non-critical */ }
}

async function createFolder(name) {
  const res = await fetch('/api/folders', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name.trim() }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    toast(err.error || 'Could not create folder');
    return null;
  }
  const folder = await res.json();
  await loadFolders();
  return folder;
}

el.addFolderBtn.addEventListener('click', async () => {
  const name = prompt('Folder name');
  if (!name || !name.trim()) return;
  if (await createFolder(name)) toast('Folder created');
});

// Favorites and Pinned accept drops too, so dragging is one gesture for
// filing, favouriting and pinning alike.
document.querySelectorAll('.nav-item[data-view="favorites"]').forEach((n) =>
  wireImageDropTarget(n, async (ids) => {
    try { await bulkRequest({ action: 'update', ids, favorite: true }); } catch (e) { return toast('Could not favorite those'); }
    toast(`${ids.length} image${ids.length === 1 ? '' : 's'} favorited`);
    load({ reset: true, silent: true });
  }));
document.querySelectorAll('.nav-item[data-view="pinned"]').forEach((n) =>
  wireImageDropTarget(n, async (ids) => {
    try { await bulkRequest({ action: 'update', ids, pinned: true }); } catch (e) { return toast('Could not pin those'); }
    toast(`${ids.length} image${ids.length === 1 ? '' : 's'} pinned`);
    load({ reset: true, silent: true });
  }));

// ---------------------------------------------------------------- nav

function selectView(view, folderId = null) {
  state.view = view;
  state.folderId = folderId;
  document.querySelectorAll('.sidebar .nav-item').forEach((n) => n.classList.remove('active'));
  if (view !== 'folder') {
    const node = document.querySelector(`.nav-item[data-view="${view}"]`);
    if (node) node.classList.add('active');
  }
  loadFolders();
  load({ reset: true });
}

document.querySelectorAll('.nav-item[data-view]').forEach((btn) => {
  btn.addEventListener('click', () => selectView(btn.dataset.view));
});

// ---------------------------------------------------------------- events

let searchTimer;
el.search.addEventListener('input', () => {
  el.searchClear.classList.toggle('visible', el.search.value.length > 0);
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    state.query = el.search.value.trim();
    load({ reset: true });
  }, 220);
});

el.searchClear.addEventListener('click', () => {
  el.search.value = '';
  el.searchClear.classList.remove('visible');
  state.query = '';
  load({ reset: true });
  el.search.focus();
});

el.zoom.addEventListener('input', () => {
  saveSettings({ cardSize: Number(el.zoom.value) });
  applyLayout();
});

el.sortSelect.addEventListener('change', () => {
  saveSettings({ sort: el.sortSelect.value });
  load({ reset: true });
});

el.layoutSwitch.querySelectorAll('.layout-btn').forEach((b) => {
  b.addEventListener('click', () => {
    saveSettings({ layout: b.dataset.layout });
    // Inline geometry from the previous layout has to go before the next
    // one measures anything.
    el.content.querySelectorAll('.card').forEach((c) => c.removeAttribute('style'));
    applyLayout();
    toast(`${b.title} layout`);
  });
});

// --- multi-select ---------------------------------------------------------

el.selectBtn.addEventListener('click', () => setSelectMode(!state.selectMode));
el.bulkClose.addEventListener('click', () => setSelectMode(false));

el.bulkSelectAll.addEventListener('click', () => {
  if (state.selection.size >= state.items.length) state.selection.clear();
  else state.items.forEach((r) => state.selection.add(r.id));
  updateSelectionUI();
});

el.bulkPin.addEventListener('click', () => bulkFlag('pinned', true));
el.bulkFav.addEventListener('click', () => bulkFlag('favorite', true));
el.bulkDelete.addEventListener('click', () => deleteImages(selectedIds()));

el.bulkFolderBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  if (!el.bulkFolderMenu.hidden) { el.bulkFolderMenu.hidden = true; return; }

  const rows = state.folders.map((f) =>
    `<button class="bulk-menu-item" data-folder="${esc(f.id)}">${esc(f.name)}</button>`).join('');
  el.bulkFolderMenu.innerHTML = `
    ${rows || '<div class="bulk-menu-empty">No folders yet</div>'}
    <button class="bulk-menu-item new">+ New folder…</button>`;
  el.bulkFolderMenu.hidden = false;

  el.bulkFolderMenu.querySelectorAll('[data-folder]').forEach((b) => {
    b.addEventListener('click', () => {
      el.bulkFolderMenu.hidden = true;
      const f = state.folders.find((x) => x.id === b.dataset.folder);
      moveToFolder(selectedIds(), f.id, f.name);
    });
  });
  const newBtn = el.bulkFolderMenu.querySelector('.new');
  if (newBtn) {
    newBtn.addEventListener('click', async () => {
      el.bulkFolderMenu.hidden = true;
      const name = prompt('Folder name');
      if (!name || !name.trim()) return;
      const folder = await createFolder(name);
      if (folder) moveToFolder(selectedIds(), folder.id, folder.name);
    });
  }
});
document.addEventListener('click', () => { el.bulkFolderMenu.hidden = true; });

el.clearGalleryBtn.addEventListener('click', clearGallery);
el.deleteBtn.addEventListener('click', () => {
  if (state.current) deleteImages([state.current.id]);
});

el.refreshBtn.addEventListener('click', () => { load({ reset: true }); loadFolders(); });
el.inspectorToggle.addEventListener('click', () => toggleInspector());
el.inspectorClose.addEventListener('click', () => toggleInspector(false));

el.settingsBtn.addEventListener('click', async () => {
  renderSettings();
  refreshExtStatus();
  el.settingsModal.hidden = false;
  try {
    const { total } = await fetch('/api/images?limit=1').then((r) => r.json());
    el.clearCount.textContent = `this gallery (${total} image${total === 1 ? '' : 's'})`;
  } catch (e) {
    el.clearCount.textContent = 'this gallery';
  }
});
el.setupExtBtn.addEventListener('click', () => { el.settingsModal.hidden = true; openExtensionSetup(); });
el.onboardNext.addEventListener('click', onboardNext);
el.onboardBack.addEventListener('click', onboardBack);
el.onboardSkip.addEventListener('click', finishOnboarding);
el.extClose.addEventListener('click', () => { el.extModal.hidden = true; load({ reset: true }); });
el.extModal.addEventListener('click', (e) => { if (e.target === el.extModal) { el.extModal.hidden = true; load({ reset: true }); } });
el.settingsClose.addEventListener('click', () => { el.settingsModal.hidden = true; load({ reset: true }); });
el.settingsModal.addEventListener('click', (e) => { if (e.target === el.settingsModal) el.settingsModal.hidden = true; });

el.favBtn.addEventListener('click', () => toggle('favorite'));
el.pinBtn.addEventListener('click', () => toggle('pinned'));
el.closeBtn.addEventListener('click', closeViewer);
el.lightbox.addEventListener('click', (e) => { if (e.target === el.lightbox) closeViewer(); });

document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '');

  if (!el.zoomView.hidden) {
    if (e.key === 'Escape') { e.preventDefault(); return closeZoomView(); }
    if (e.key === '+' || e.key === '=') { e.preventDefault(); return setZoom(zoom.scale * 1.25); }
    if (e.key === '-' || e.key === '_') { e.preventDefault(); return setZoom(zoom.scale / 1.25); }
    if (e.key === '0') { e.preventDefault(); return resetZoomToFit(); }
    if (e.key === '1') { e.preventDefault(); return setZoom(1); }
    return;
  }

  if ((e.key === 'f' || e.key === 'F') && !typing && !el.lightbox.hidden) {
    e.preventDefault();
    return openZoomView(state.current);
  }

  if (e.key === 'Escape') {
    if (!el.confirmModal.hidden) return;
    if (!el.extModal.hidden) return (el.extModal.hidden = true);
    if (!el.onboardModal.hidden) return finishOnboarding();
    if (!el.settingsModal.hidden) return (el.settingsModal.hidden = true);
    if (!el.lightbox.hidden) return closeViewer();
    if (state.selectMode) return setSelectMode(false);
  }
  if (e.key === 'Enter' && !el.onboardModal.hidden && !typing) {
    e.preventDefault();
    return onboardNext();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
    e.preventDefault(); el.search.focus(); el.search.select();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === 'a' && !typing && el.lightbox.hidden) {
    e.preventDefault();
    setSelectMode(true);
    state.items.forEach((r) => state.selection.add(r.id));
    updateSelectionUI();
  }
  if ((e.key === 'Delete' || e.key === 'Backspace') && !typing && el.confirmModal.hidden) {
    if (state.selection.size) { e.preventDefault(); deleteImages(selectedIds()); return; }
    if (state.current) { e.preventDefault(); deleteImages([state.current.id]); return; }
  }
  if (el.lightbox.hidden) return;
  if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
    const i = state.items.findIndex((x) => x.id === state.current?.id);
    if (i === -1) return;
    const next = e.key === 'ArrowRight' ? i + 1 : i - 1;
    if (next >= 0 && next < state.items.length) {
      selectRecord(state.items[next]);
      openViewer(state.items[next]);
    }
  }
});

// Pick up newly captured images without the user hitting refresh.
// Pick up newly captured images without the user hitting refresh.
//
// This deliberately keeps running while the Settings / setup / extension
// modals are open: those are exactly the windows you have open while
// setting the extension up, and suppressing refresh there meant captures
// could land while the grid sat stale behind the dialog. Only the lightbox
// pauses it, since re-rendering underneath the image you're looking at is
// pointless churn.
setInterval(() => {
  if (!el.lightbox.hidden || state.loading) return;
  if (state.offset > state.limit) return;          // user paged past the first screen
  if (state.selectMode || state.selection.size) return; // don't shuffle a live selection
  if (!el.confirmModal.hidden) return;
  load({ reset: true, silent: true });
}, 5000);

// Exposed on purpose: it makes the gallery inspectable from the WebView's
// devtools console when a layout or selection problem needs diagnosing.
window.gallery = { state, load, render, applyLayout, updateSelectionUI, setSelectMode };

(async () => {
  await loadSettings();
  loadStorageInfo();
  renderInspector();
  loadFolders();
  await load({ reset: true });
  maybeStartOnboarding();
})();
